import React, { useEffect, useState } from "react";
import ProductTile from "../../components/ProductTile/ProductTile";
import './Home.css'

const Home = () => {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(false);
  

  async function fetchProductData() {
    setLoading(true);
    try {
      const res = await fetch("https://fakestoreapi.com/products");
      const data = await res.json();
      console.log(data);
      if (data) {
        setProducts(data);
        setLoading(false);
      }
    } catch (e) {
      console.log(e);
      setLoading(false);
    }
  }

  useEffect(() => {
    fetchProductData();
  }, []);

  

  return (
    <div className="homeContainer">
      {loading ? (
        <h2>Loading, Please wait...</h2>
      ) : (
        <div className="homeProductContainer">
          {products && products.length > 0 ? (
            products.map((product) => <ProductTile key={product.id} product={product} />)
          ) : (
            <h2>Something wrong</h2>
          )}
        </div>
      )}
    </div>
  );
};

export default Home;
