import { Route, Routes } from "react-router-dom";
import Navbar from "./components/Navbar/Navbar";
import Home from "./pages/Home/Home";
import Cart from "./pages/Cart/Cart";
import Favorite from "./pages/Favorite/Favorite";
import Detail from "./pages/Detail/Detail";

function App() {
  return (
    <>
      <Navbar />
      <div className="holyContainer">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/cart" element={<Cart />} />
          <Route path="/favorite" element={<Favorite />} />
          <Route path="/detail/:id" element={<Detail/>}/>
        </Routes>
      </div>
    </>
  );
}

export default App;
