import React from "react";
import "./CartTile.css";
import { useDispatch } from "react-redux";
import { removeFromCart } from "../../store/cartSlice";

const CartTile = ({ item }) => {
  const dispatch = useDispatch();

  function handleRemoveFromCart() {
    dispatch(removeFromCart(item.id));
  }

  return (
    <div className="cartTile">
      <div className="imgContainerCT">
        <img src={item.image} alt="" />
      </div>
      <div className="infoDetails">
        <div className="top">
          <h4>{item.title}</h4>
          <p>
            <strong>Price:</strong> ${item.price}
          </p>
        </div>
        <div className="bottom">
          <button className="removeBtn" onClick={handleRemoveFromCart}>
            Remove
          </button>
          <button className="favBtn">Favorite</button>
        </div>
      </div>
    </div>
  );
};

export default CartTile;
