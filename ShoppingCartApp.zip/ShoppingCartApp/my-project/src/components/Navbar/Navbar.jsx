import React, { useState, useEffect } from "react";
import "./Navbar.css";
import { Link } from "react-router-dom";
import logo from "../../assets/adidas.jpg";

const Navbar = () => {
  const [searchParam, setSearchParam] = useState("");

  async function fetchSearchData(e) {
    e.preventDefault();
    try {
        const res = await fetch("https://fakestoreapi.com/products");

        if (!res.ok) {
            throw new Error(`HTTP error! Status: ${res.status}`);
        }

        const products = await res.json(); // Convert response to JSON

        // Filter products based on title (case-insensitive search)
        const searchResults = products.filter(product => 
            product.title.toLowerCase().includes(searchParam.toLowerCase())
        );

        console.log(searchResults); // Log matching products
    } catch (error) {
        console.error("Error fetching data:", error.message);
    }
}


  return (
    <div className="navBar">
      <div className="imgContainer">
        <Link to={"/"}>
          <img src={logo} alt="" />
        </Link>
      </div>
      <div className="others">
        <form onSubmit={fetchSearchData}>
          <input
            value={searchParam}
            type="text"
            placeholder="Search"
            onChange={(e) => setSearchParam(e.target.value)}
          />
        </form>
        <Link to={"/favorite"} className="link">
          Favorite
        </Link>
        <Link to={"/cart"} className="link">
          Cart
        </Link>
      </div>
    </div>
  );
};

export default Navbar;
