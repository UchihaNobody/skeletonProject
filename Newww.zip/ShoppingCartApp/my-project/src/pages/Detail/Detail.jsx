import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import "./Detail.css";
import heartLogo from "../../assets/heartLogo.png";
import { useDispatch } from "react-redux";
import { addToCart } from "../../store/cartSlice";

const Detail = () => {
  const { id } = useParams();
  const [productDetails, setProductDetails] = useState(null);
  const dispatch = useDispatch();

  async function fetchDetailProductData(id) {
    try {
      const res = await fetch(`https://fakestoreapi.com/products/${id}`);
      const data = await res.json();

      if (data) {
        setProductDetails(data);
      }
    } catch (e) {
      console.log(e);
    }
  }

  useEffect(() => {
    fetchDetailProductData(id);
  }, []);

  const generateStars = (rating) => {
    const fullStars = Math.floor(rating);
    const halfStar = rating % 1 >= 0.5 ? 1 : 0;
    const emptyStars = 5 - fullStars - halfStar;

    return (
      <>
        {"★".repeat(fullStars)}
        {halfStar ? "☆" : ""}
        {"☆".repeat(emptyStars)}
      </>
    );
  };

  function handleAddToCart() {
    dispatch(addToCart(productDetails));
  }

  return (
    <div className="forDetail">
      {productDetails ? (
        <div className="detailContainer">
          <div className="imgContainerPD">
            <img src={productDetails.image} alt="" />
          </div>
          <div className="infoContainerPD">
            <div className="info">
              <h2>{productDetails.title}</h2>
              <p>
                <strong>Category:</strong> {productDetails.category}
              </p>
              <p>
                <strong>Price:</strong> {productDetails.price}
              </p>
              <p>
                <strong>Description:</strong> {productDetails.description}
              </p>
              <p>
                <strong>Rating:</strong>
                <span className="rating">
                  {generateStars(productDetails.rating.rate)}
                </span>{" "}
                ({productDetails.rating.count} reviews)
              </p>
            </div>
            <div className="btns">
              <button onClick={handleAddToCart} className="cartBtn">
                Add to Cart
              </button>
              <button className="favBtn">
                <img src={heartLogo} alt="" />
              </button>
            </div>
          </div>
        </div>
      ) : (
        <h2>apk</h2>
      )}
    </div>
  );
};

export default Detail;
