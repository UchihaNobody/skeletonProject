import React, { useEffect, useState } from "react";
import { useSelector } from "react-redux";
import CartTile from "../../components/CartTile/CartTile";
import "./Cart.css";

const Cart = () => {
  const cartItems = useSelector((state) => state.cart);
  const [totalProducts, setTotalProducts] = useState(0);

  useEffect(() => {
    setTotalProducts(
      cartItems.reduce((accumulator, item) => {
        return (accumulator + item.price * item.quantity);
      }, 0)
    );
  }, [cartItems]);

  const totalQuantity = cartItems.reduce((acc, item) => acc + item.quantity, 0);



  console.log(cartItems, totalProducts);

  return (
    <div>
      {cartItems && cartItems.length ? (
        <div className="cartContainer">
          <div className="itemContainer">
            {cartItems.map((item, index) => (
              <CartTile key={index} item={item} />
            ))}
          </div>
          <div className="order-summary">
            <h2>Order Summary</h2>
            <div className="summary-item">
              <span>
                {totalQuantity > 1
                  ? `${totalQuantity} items`
                  : `${totalQuantity} item`}
              </span>
              <span>${totalProducts}</span>
            </div>
            <div className="summary-item">
              <span>Tax</span>
              <span>$00.00</span>
            </div>
            <div className="summary-item">
              <span>Quantity</span>
              <span>{totalQuantity}</span>
            </div>

            <div className="summary-item total">
              <span>Total</span>
              <span>${totalProducts}</span>
            </div>
          </div>
        </div>
      ) : (
        <h2 className="mtText">Your Cart is Empty</h2>
      )}
    </div>
  );
};

export default Cart;
