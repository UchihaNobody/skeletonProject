import React from "react";
import "./ProductTile.css";
import { Link } from "react-router-dom";

const ProductTile = ({ product }) => {
  return (
    <Link className="hello" to={`/detail/${product.id}`}>
      <div className="productTile">
        <div className="imgContainerPT">
          <img src={product.image} alt="" />
        </div>
        <div className="infoContainer">
          <h4 className="price">${product.price}</h4>
          <h4 className="title">{product.title}</h4>
          <p className="category">{product.category}</p>
        </div>
      </div>
    </Link>
  );
};

export default ProductTile;
