import React, { useState, useEffect } from "react";
import "./Navbar.css";
import { Link } from "react-router-dom";
import logo from "../../assets/adidas.jpg";
import { useDispatch, useSelector } from "react-redux";
import { setSearchQuery } from "../../store/searchSlice";

const Navbar = () => {
  const dispatch = useDispatch();
  const searchQuery = useSelector((state) => state.search.searchQuery);

  function handleSearch(e) {
    dispatch(setSearchQuery(e.target.value));
  }

  return (
    <div className="navBar">
      <div className="imgContainer">
        <Link to={"/"}>
          <img src={logo} alt="" />
        </Link>
      </div>
      <div className="others">
        <form>
          <input
            value={searchQuery}
            type="text"
            placeholder="Search"
            onChange={handleSearch}
          />
        </form>
        <Link to={"/favorite"} className="link">
          Favorite
        </Link>
        <Link to={"/cart"} className="link">
          Cart
        </Link>
      </div>
    </div>
  );
};

export default Navbar;
